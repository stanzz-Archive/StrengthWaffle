package com.stanzz.strengthsmp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

public final class StrengthSMP extends JavaPlugin implements Listener {
    private NamespacedKey strengthItemKey;
    private static final String PREFIX = ChatColor.GOLD + "[StrengthSMP] " + ChatColor.RESET;
    private static final int MAX_LEVEL = 100000;

    @Override public void onEnable() {
        strengthItemKey = new NamespacedKey(this, "strength_sunflower");
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("StrengthSMP enabled.");
    }

    private String path(UUID id) { return "players." + id; }
    public int getStrength(Player p) { return Math.max(0, getConfig().getInt(path(p.getUniqueId()), 0)); }
    private void setStrength(Player p, int value) {
        int safe = Math.max(0, Math.min(MAX_LEVEL, value));
        getConfig().set(path(p.getUniqueId()), safe);
        saveConfig();
    }
    private ItemStack makeSunflower(int amount) {
        ItemStack item = new ItemStack(Material.SUNFLOWER, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + "✦ Sunflower of Strength ✦");
        meta.setLore(java.util.List.of(ChatColor.GRAY + "Right-click to gain +1 Strength", ChatColor.DARK_GRAY + "Stanzz Studio"));
        meta.addEnchant(Enchantment.UNBREAKING, 1, true); // enchantment glint
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(strengthItemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }
    private boolean isStrengthSunflower(ItemStack item) {
        if (item == null || item.getType() != Material.SUNFLOWER || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(strengthItemKey, PersistentDataType.BYTE);
    }

    @EventHandler public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (!isStrengthSunflower(item)) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        int old = getStrength(p);
        if (old >= MAX_LEVEL) { p.sendMessage(PREFIX + ChatColor.RED + "Strength sudah mencapai batas maksimum."); return; }
        if (item.getAmount() <= 1) p.getInventory().setItemInMainHand(null); else item.setAmount(item.getAmount() - 1);
        setStrength(p, old + 1);
        p.sendMessage(PREFIX + ChatColor.GREEN + "Strength kamu sekarang: " + ChatColor.YELLOW + (old + 1));
    }

    @EventHandler public void onBlockPlace(BlockPlaceEvent event) {
        if (isStrengthSunflower(event.getItemInHand())) event.setCancelled(true);
    }

    @EventHandler public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        int level = getStrength(victim);
        if (level <= 0) return;
        setStrength(victim, level - 1);
        // The lost point becomes a collectible sunflower. It is not added to the normal death drops.
        event.getDrops().add(makeSunflower(1));
        victim.sendMessage(PREFIX + ChatColor.RED + "Kamu kehilangan 1 Strength. Sisa: " + (level - 1));
        Player killer = victim.getKiller();
        if (killer != null) killer.sendMessage(PREFIX + ChatColor.GOLD + "" + ChatColor.BOLD + victim.getName() + ChatColor.RESET + " menjatuhkan 1 Sunflower of Strength!");
    }

    @EventHandler public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        int level = getStrength(attacker);
        if (level > 0) event.setDamage(event.getDamage() * (1.0 + (Math.min(level, 1000) * 0.10)));
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Use /strength give <player> <amount> or /strength set <player> <level>."); return true; }
            p.sendMessage(PREFIX + "Strength kamu: " + ChatColor.YELLOW + getStrength(p));
            p.sendMessage(ChatColor.GRAY + "Setiap level menambah damage 10%.");
            return true;
        }
        if (!sender.hasPermission("strengthsmp.admin")) { sender.sendMessage(PREFIX + ChatColor.RED + "Kamu tidak punya izin."); return true; }
        if (args.length == 3 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("set"))) {
            Player target = getServer().getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(PREFIX + ChatColor.RED + "Pemain harus sedang online."); return true; }
            int amount;
            try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { sender.sendMessage(PREFIX + ChatColor.RED + "Jumlah harus angka."); return true; }
            if (args[0].equalsIgnoreCase("give")) {
                if (amount < 1 || amount > 64) { sender.sendMessage(PREFIX + "Jumlah item harus 1-64."); return true; }
                target.getInventory().addItem(makeSunflower(amount)).values().forEach(drop -> target.getWorld().dropItemNaturally(target.getLocation(), drop));
                sender.sendMessage(PREFIX + "Memberikan " + amount + " Sunflower of Strength ke " + target.getName() + ".");
            } else {
                setStrength(target, amount);
                target.sendMessage(PREFIX + "Strength kamu diatur menjadi " + getStrength(target) + ".");
                sender.sendMessage(PREFIX + "Strength " + target.getName() + " = " + getStrength(target));
            }
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "/strength" + ChatColor.GRAY + " - cek levelmu");
        sender.sendMessage(ChatColor.YELLOW + "/strength give <player> <1-64>" + ChatColor.GRAY + " - beri sunflower");
        sender.sendMessage(ChatColor.YELLOW + "/strength set <player> <level>" + ChatColor.GRAY + " - atur level");
        return true;
    }
}
