STRENGTH SMP - Stanzz Studio
Target: Paper Minecraft 1.21.11, Java 21

FEATURES
- Sunflower of Strength custom item with enchantment glint.
- Right-click consumes it and adds 1 permanent Strength level.
- The special sunflower cannot be placed as a block.
- Strength levels persist in plugins/StrengthSMP/config.yml across restarts.
- On death, a player with Strength loses 1 level and drops one special sunflower.
- Each Strength level adds 10% outgoing melee damage (damage scaling capped at 1000 levels).
- Admin commands:
  /strength                         view your level
  /strength give <player> <1-64>    give special sunflower item(s)
  /strength set <player> <level>    set a player's level
- Permission for admin commands: strengthsmp.admin (default: OP)

INSTALL
1. This ZIP is the plugin SOURCE PROJECT, not a compiled .jar.
2. Build it with Maven and Java 21: run `mvn package` in this folder.
3. The compiled plugin will be target/StrengthSMP-1.0.0.jar.
4. Upload that JAR to the server's plugins folder, then restart the server.

NOTES
- Paper API dependency is set to 1.21.11-R0.1-SNAPSHOT.
- This environment could not download dependencies or compile the JAR, so the JAR is not included.
- The dropped sunflower is a representation of the lost strength point. The killer does not automatically gain a level; the dropped item can be picked up and right-clicked by any player.
